import numpy as np
import cv2
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import load_model
import gradio as gr
from g4f.client import Client

print("TensorFlow version:", tf.__version__)
# Load the trained generator model
generator = load_model("C:/Users/hp/Downloads/generatorr_model.keras")
client = Client()

def generate_and_process_image(user_prompt, n=5):
    # Generate new images
    latent_dim = 100
    noise = np.random.normal(0, 1, (n, latent_dim))
    generated_images = generator.predict(noise)

    # Apply Canny edge detection to each generated image
    canny_images = [cv2.Canny((generated_images[i].reshape(64, 64) * 255).astype(np.uint8), 50, 150) for i in range(n)]

    # Invert the colors of the Canny edge images
    inverted_canny_images = [cv2.bitwise_not(canny_img) for canny_img in canny_images]

    # Save the first inverted Canny edge image
    cv2.imwrite("generated_image.png", inverted_canny_images[0])

    # Display the inverted Canny edge image (optional)
    plt.imshow(inverted_canny_images[0], cmap='gray')
    plt.axis('off')
    plt.show()

    # Get the text response from the chatbot
    text_response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": user_prompt}],
    ).choices[0].message.content

    return "generated_image.png", text_response

# Initialize the chatbot interface
interface = gr.Interface(
    fn=generate_and_process_image,
    inputs=gr.Textbox(lines=2, placeholder="What type of Floor Plan do you want..."),
    outputs=["image", "text"],
    title="AutoPlan Chatbot",
    css="footer {visibility: hidden}"
)

if __name__ == "__main__":
    interface.launch()
