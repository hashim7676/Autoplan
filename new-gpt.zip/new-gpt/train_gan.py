import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from sklearn.model_selection import train_test_split
import os
from tensorflow.keras.layers import Input, Dense, Conv2D, MaxPooling2D, UpSampling2D, BatchNormalization, Activation, Reshape, Flatten, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam

# Define functions for model building, training loop, etc.
# (Include all the code related to model building, training, and saving models)
from tensorflow.keras.layers import Input, Dense, Conv2D, MaxPooling2D, UpSampling2D, BatchNormalization, Activation, Reshape, Flatten, Dropout
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam

# Load the dataset
dataset_path = "./CustomImagesGT/ImagesGT"
def load_dataset(dataset_path, img_size=(64, 64)):
    images = []

    # Iterate through each image in the folder
    for image_file in os.listdir(dataset_path):
        image_path = os.path.join(dataset_path, image_file)

        # Load image, resize, and convert to array
        img = load_img(image_path, color_mode='grayscale', target_size=img_size)
        img_array = img_to_array(img) / 255.0  # Normalize pixel values to [0, 1]

        # Add image to the list
        images.append(img_array)

    return np.array(images)

# Load the dataset
images = load_dataset(dataset_path)
train_images, test_images = train_test_split(images, test_size=0.2, random_state=42)


# Set the input shape
input_shape = (64, 64, 1)
latent_dim = 100  # Adjust the latent dimension according to your preference

# Generator
def build_generator(latent_dim, img_shape):
    model_input = Input(shape=(latent_dim,))
    x = Dense(128)(model_input)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(0.2)(x)  # Add dropout
    x = Reshape((8, 8, 2))(x)  # Adjust the shape based on the desired output size

    x = Conv2D(128, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(0.2)(x)  # Add dropout
    x = UpSampling2D((2, 2))(x)

    x = Conv2D(64, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(0.2)(x)  # Add dropout
    x = UpSampling2D((2, 2))(x)

    x = Conv2D(32, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(0.2)(x)  # Add dropout
    x = UpSampling2D((2, 2))(x)

    generated_img = Conv2D(1, (3, 3), activation='sigmoid', padding='same')(x)

    generator = Model(model_input, generated_img)
    return generator

# Discriminator
def build_discriminator(img_shape):
    model_input = Input(shape=img_shape)
    x = Conv2D(32, (3, 3), padding='same')(model_input)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(0.2)(x)  # Add dropout
    x = MaxPooling2D((2, 2), padding='same')(x)

    x = Conv2D(64, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(0.2)(x)  # Add dropout
    x = MaxPooling2D((2, 2), padding='same')(x)

    x = Conv2D(128, (3, 3), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(0.2)(x)  # Add dropout
    x = MaxPooling2D((2, 2), padding='same')(x)

    x = Flatten()(x)
    x = Dense(1, activation='sigmoid')(x)

    discriminator = Model(model_input, x)
    discriminator.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])
    return discriminator

# GAN
def build_gan(generator, discriminator):
    discriminator.trainable = False
    model_input = Input(shape=(latent_dim,))
    generated_img = generator(model_input)
    validity = discriminator(generated_img)

    gan = Model(model_input, validity)
    gan.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy')
    return gan

# Build the generator, discriminator, and GAN
generator = build_generator(latent_dim, input_shape)
discriminator = build_discriminator(input_shape)
gan = build_gan(generator, discriminator)



# Split the dataset into training and testing sets
train_images, test_images = train_test_split(images, test_size=0.2, random_state=42)

# Print the shapes of the training and testing sets
#print("Training Set Shape:", train_images.shape)
#print("Testing Set Shape:", test_images.shape)

# Initialize empty lists to store losses
d_loss_list = []
g_loss_list = []
d_accuracy_list = []

# Train the GAN model
epochs = 1000   # You can adjust the number of epochs
batch_size = 64  # You can adjust the batch size

for epoch in range(epochs):
    # ---------------------
    #  Train Discriminator
    # ---------------------

    # Select a random batch of images
    idx = np.random.randint(0, train_images.shape[0], batch_size)
    real_images = train_images[idx]

    # Generate a batch of fake images
    noise = np.random.normal(0, 1, (batch_size, latent_dim))
    generated_images = generator.predict(noise)

    # Labels for real and generated images
    valid = np.ones((batch_size, 1))
    fake = np.zeros((batch_size, 1))

    # Train the discriminator
    d_loss_real = discriminator.train_on_batch(real_images, valid)
    d_loss_fake = discriminator.train_on_batch(generated_images, fake)
    d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

    # Save discriminator accuracy
    d_accuracy_list.append(d_loss[1])

    # ---------------------
    #  Train Generator
    # ---------------------

    # Generate a batch of noise
    noise = np.random.normal(0, 1, (batch_size, latent_dim))

    # Labels for generated images
    valid = np.ones((batch_size, 1))

    # Train the generator
    g_loss = gan.train_on_batch(noise, valid)
    
    # Append losses to lists
    d_loss_list.append(d_loss[0])
    g_loss_list.append(g_loss)

    # Print progress
    if epoch % 100 == 0:
        print(f"Epoch {epoch}, D Loss: {d_loss[0]}, G Loss: {g_loss}")


        





# Train the GAN model
# (Include the training loop)

# Optionally, save the trained models
# (Include code for saving the trained models)
# Optionally, save the trained models
generator.save("C:/Users/hp/Downloads/generator_model.keras")
discriminator.save("C:/Users/hp/Downloads/discriminator_model.keras")
gan.save("C:/Users/hp/Downloads/gan_model.keras")
