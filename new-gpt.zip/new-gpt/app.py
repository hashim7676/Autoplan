import gradio as gr
from g4f.client import Client

client = Client()

def chatbot_response(user_prompt):
    # Generating image response
    image_response = "C:/Users/hp/Downloads/imaaag.jpg"  # Placeholder for image path
    # Generating text response
    text_response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": user_prompt}],
    ).choices[0].message.content
    return image_response, text_response

interface = gr.Interface(
    fn=chatbot_response,
    inputs=gr.Textbox(lines=2, placeholder="What type of Floor Plan do you want..."),
    outputs=["image", "text"],
    title="AutoPlan Chatbot",
    css="footer {visibility: hidden}"
    #description="Ask any question"
)

if __name__ == "__main__":
    interface.launch()
