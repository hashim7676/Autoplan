import numpy as np
from tensorflow.keras.models import load_model

# Load the trained generator model
generator = load_model("C:/Users/hp/Downloads/generator_model.keras")

# Generate new images
n = 5
latent_dim = 100
noise = np.random.normal(0, 1, (n, latent_dim))
generated_images = generator.predict(noise)

