from flask import Flask, render_template, request
from g4f.client import Client

app = Flask(__name__)
client = Client()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_input = request.form['user_input']
    response = chatbot_response(user_input)
    return response

def chatbot_response(user_input):
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": user_input}],
    )
    return response.choices[0].message.content

if __name__ == '__main__':
    app.run(debug=True)
