import tensorflow as tf

print(tf._version_)